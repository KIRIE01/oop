package Servelet;

import java.io.IOException;

import database.UserImpli;
import functions.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Log")
public class Log extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Log() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String username = request.getParameter("uid");
		String password = request.getParameter("pass");
				
	User u = new User();
	
	u.setName(0, username);
	u.setPassword( password);
	
	UserImpli serv = new UserImpli();
	
	if(serv.validate(u.getName(),u.getPassword()) == true){
		response.sendRedirect("Admin.jsp");
	}
	
	else if(username.equals("admin") && password.equals("admin123")){
		
		response.sendRedirect("Admin.jsp");
	}
	else{
		 response.sendRedirect("Error.jsp");
	}
}

}


	
