package Servelet;

import java.io.IOException;


import database.UserImpli;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/RegisterS")
public class RegisterS extends HttpServlet{
	private static final long serialVersionUID =1L;
	
	public RegisterS() {
		super();}
		
	protected void doGet(HttpServletResponse response) throws ServletException, IOException{
		Object request = null;
		response.getWriter().append("Served at: ").append(((HttpServletRequest) request).getContextPath());
		}
	
protected void dopost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	doGet(request, response);
	
	String name = request.getParameter("name");
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	
		UserImpli h = new UserImpli();
		boolean is;
	is = h.insertuser(name,username,password);
	
	if (is == true) {
		
		response.sendRedirect("Admin.jsp");
	}
	else {
		response.sendRedirect("Error.jsp");
	}
		
	}
	
}


