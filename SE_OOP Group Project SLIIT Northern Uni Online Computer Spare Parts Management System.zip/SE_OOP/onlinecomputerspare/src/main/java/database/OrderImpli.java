package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import functions.Order;
import impli.orderim;

public class OrderImpli implements orderim{
	
	private static final String Select_Order_By_ID="select * from Order where id=?";
	private static final String Insert_Order_SQL="insert into Order"+"(name) values" + "(?)";
	private static final String SELECT_ALL_ORDER="Select * From Order";
	private static final String UPDATE_Order_SQL="update Order set name=?, where id=?;";
	private static final String DELETE_Order_SQL="delete from Order where id= ?;";
	//private Order d;
	//private String name;

	public OrderImpli() {
		// TODO Auto-generated constructor stub
	}

	public Order getOrder(int id) throws SQLException {
		// TODO Auto-generated method stub
		Order d=null;
		try {Connection connection =dbconnect.getdbconnection();
			PreparedStatement preparedStatement=connection.prepareStatement(Select_Order_By_ID);
			preparedStatement.setInt(1,id);
			System.out.println(preparedStatement);
			ResultSet re = preparedStatement.executeQuery();
			
			while (re.next()) {
				String idString =re.getString("id");
				String nameString =re.getString("name");
				d=new Order(idString, nameString);
				}
			
		} catch (SQLException e) {
			// TODO: handle exception
			printSQLException(e);
		}
		return d;
	}

	private void printSQLException(SQLException ex) {
		// TODO Auto-generated method stub
		for (Throwable e : ex) {
			if(e instanceof SQLException) {
				e.printStackTrace(System.err );
				System.err.println("SQLState: " + ((SQLException)e).getSQLState());
				System.err.println("Error Code: " + ((SQLException)e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t !=null) {
					System. out.println("Cause: " +t);
					t=t.getCause();
				}
			
			}
		}
	}

	@Override
	public void addOrder(Order d) throws SQLException {
		// TODO Auto-generated method stub
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(Insert_Order_SQL)){

			preparedStatement.setString(1, d.getName());
			
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	@Override
	public ArrayList<Order> getOrders() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<Order> Orderlist=new ArrayList<Order>();
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement( SELECT_ALL_ORDER)){
			ResultSet re = preparedStatement.executeQuery();
			while (re.next()) {
				 String id=re.getString("id");
				String name =re.getString("name");
				
				 Orderlist.add(new Order(id, name));
			}}
		catch (SQLException e) {
			printSQLException(e);
		}
		
		return Orderlist;
	}

	@Override
	public boolean updateOrder(Order d) throws SQLException {
		// TODO Auto-generated method stub
		boolean rowUpdated;
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_Order_SQL)){
			
			preparedStatement.setString(1, d.getName());
			preparedStatement.setString(5, d.getid());
			rowUpdated = preparedStatement.executeUpdate() > 0;
			
		}
		return rowUpdated;
	}

	public boolean delete(int id) throws SQLException {
		// TODO Auto-generated method stub
		boolean rowDeleted;
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(DELETE_Order_SQL)){
			preparedStatement.setInt(1, id);
			rowDeleted = preparedStatement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	@Override
	public Order getOrder(Integer id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Integer id) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

}
