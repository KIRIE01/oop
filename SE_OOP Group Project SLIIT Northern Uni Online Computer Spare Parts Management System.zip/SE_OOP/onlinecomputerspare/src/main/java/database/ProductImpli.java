	package database;
	
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.ArrayList;
	
	import functions.Product;
	import impli.productim;
	
	public class ProductImpli implements productim {
		  //private static final Logger log =Logger.getLogger(ProductImpli.class.getName()n);
		  private Connection connection;
		  private PreparedStatement preparedStatement;
		  
		  public ProductImpli() {
			  try {
				connection=dbconnect.getdbconnection();
			  		} catch (Exception e) {
				//log.log(Level.ALL,e.getMessage());
			}
		  }
		  public void addProduct(Product product) {
			  try {
				String qI = "INSERT INTO products(pid,pname,price)VALUES (?,?,?)";
				 preparedStatement=connection.prepareStatement(qI);
				preparedStatement.setString(1, product.getPid());
				preparedStatement.setString(2, product.getPname());
				preparedStatement.setFloat(3, product.getPrice());
				preparedStatement.executeUpdate();
			} catch (Exception e) {
				// TODO: handle exception
			}  
		  }
		  public Product updateProduct(String pid, Product product) {
			  try {
				  String qU = "UPDATE products set pname=? , price=? where pid=?";
				  preparedStatement=connection.prepareStatement(qU);
				  preparedStatement.setString(1, pid);
				 
					preparedStatement.setString(2, product.getPname());
					preparedStatement.setFloat(3, product.getPrice());
					preparedStatement.execute();
			  }catch (Exception e) {
					// TODO: handle exception
				}  
			  return product;
		  }
		  
		  public void delete(String pid) {
			 try {
			  String qr = "DELETE from products where pid=?";
			  preparedStatement= connection.prepareStatement(qr);
			  preparedStatement.setString(1,pid );
			  preparedStatement.executeUpdate();
			 	}catch (Exception e) {
			 	}
			 }
		  public ArrayList<Product> getProducts(){
			  ArrayList<Product> productlist = new ArrayList<>();
			  try {
				  String queryGetAll = "SELECT * FROM products";
				  
				  preparedStatement = connection.prepareStatement(queryGetAll);
				  
				  ResultSet resultSet = preparedStatement.executeQuery();
				  while (resultSet.next()) {
					  Product product = new Product();
					  product.setPid(resultSet.getString("pid"));
					  product.setPname(resultSet.getString("pname"));
					  product.setPrice(resultSet.getFloat("price"));
					  productlist.add(product);
				}
				  
			  }catch (Exception e) {
				// TODO: handle exception
			}
			return productlist;
		  }
		@Override
		public Product addproduct(Product d) throws SQLException {
			// TODO Auto-generated method stub
			
			return null;
		}
		@Override
		public boolean updateproduct(Product d) throws SQLException {
			// TODO Auto-generated method stub
			return false;
		}
		@Override
		public boolean delete(int id) throws SQLException {
			// TODO Auto-generated method stub
			return false;
		}
		
	}
		   

		  
		 
		
	
		
		
	
	
