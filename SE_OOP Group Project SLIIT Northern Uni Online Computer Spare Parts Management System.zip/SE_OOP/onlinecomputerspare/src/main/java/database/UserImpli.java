package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.apache.catalina.filters.AddDefaultCharsetFilter;

import functions.Order;
import functions.User;
import impli.userim;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserImpli implements userim{
	
	public static final Logger log = Logger.getLogger(UserImpli.class.getName());
	
	private static Connection connection;
	
	private static PreparedStatement pr;

	private Statement statement;

	private String Update_Order_SQL;

	private String DELETE_Order_SQL;
	
	
	public boolean insertuser(String name,String username,String password) {
		
		boolean isSuccess = false;
		try {
			connection = dbconnect.getdbconnection();
			
			statement= connection.createStatement();
			
		String sql="Insert into customers values('"+name+"','"+username+"','"+password+"')";
		
		int rs2 = statement.executeUpdate(sql);
		
		if(rs2 > 0) {
			isSuccess = true;
		}
		else {
			isSuccess =false;}
		}
			
		
	catch (Exception e) {
		e.printStackTrace();
	}
	return isSuccess;
	}
	public boolean validate(String name,String pass){
		boolean status=false;
			
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection = dbconnect.getdbconnection();
			pr = connection.prepareStatement("select * from customers where username =? and password = ? ");
			
			pr.setString(1,name);
			pr.setString(2,pass);
	
			ResultSet rs=pr.executeQuery();
			status = rs.next();
	
	
		}catch(Exception e){
			System.out.println(e);
		}
			return status;
	}
	public void insertuser(User u) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public User getUser(String name) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Void addUser(User d) throws SQLException {
		// TODO Auto-generated method stub
		try(Connection connection = dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(null)){
			preparedStatement.setString(1,d.getName() );
		}
		return null;
	}
	@Override
	public ArrayList<User> getUsers(String SELECT_ALL_User) throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<User> Orderlist=new ArrayList<User>();
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_User)){
			ResultSet re = preparedStatement.executeQuery();
			while (re.next()){
				String name=re.getString("getname");
				String user = re.getString("getusername");
				String password = re.getString("getpassword");
			}
		}
		return null;
	}
	@Override
	public boolean updateUser(User d) throws SQLException {
		// TODO Auto-generated method stub
		boolean rowUpdated;
		try (Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(Update_Order_SQL)){
		preparedStatement.setString(1,d.getName() );
		preparedStatement.setString(1, d.getUsername());
		preparedStatement.setString(1, d.getUsername());
		rowUpdated = preparedStatement.executeUpdate() > 0;	
		}
		return rowUpdated;
	}
	@Override
	public boolean delete(String name) throws SQLException {
		// TODO Auto-generated method stub
		boolean rowDeleted;
		try(Connection connection=dbconnect.getdbconnection();
				PreparedStatement preparedStatement = connection.prepareStatement(DELETE_Order_SQL)){
			((User) preparedStatement).setName(1, name);
			rowDeleted=preparedStatement.executeUpdate()>0;
		}
		return false;
	}
	@Override
	public ArrayList<User> getUsers() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}


