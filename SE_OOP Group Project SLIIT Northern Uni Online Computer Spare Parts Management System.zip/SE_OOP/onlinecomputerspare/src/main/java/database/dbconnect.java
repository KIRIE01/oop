package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbconnect {
	
	private static Connection connection;
	// singleton pattern
		private dbconnect() {
			
			
		}
		public static Connection getdbconnection() {
			final String DRIVER_NAME="com.mysql.jdbc.Driver";
			final String URL="jdbc:mysql://localhost:3306/computer";
			final String USERNAME = "root";
			final String PASSWORD= "1234";
			
			connection = null;
				try {
					Class.forName(DRIVER_NAME);
					System.out.println("driver name");
					connection=DriverManager.getConnection(URL,USERNAME,PASSWORD);
				}catch (ClassNotFoundException|SQLException e) {
					e.printStackTrace();
				}
				return connection;
					
					
					
					
				}
			
		}


