package functions;

public class User {
	private String name;
	private String username;
	private String password;
	
	public User() {
		
	}

	public String getName() {
		return name;
	}

	public void setName(int i, String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setName(String parameter) {
		// TODO Auto-generated method stub
		
	}
		
	
} 
	
