package impli;

import java.sql.SQLException;
import java.util.ArrayList;

import functions.Order;


public interface orderim {
	public Order getOrder (Integer id) throws SQLException;
	
	public void addOrder (Order d)  throws SQLException;
	
	public ArrayList<Order>getOrders() throws SQLException;
	
	public boolean updateOrder(Order d)throws SQLException;
	
	public boolean delete(Integer id ) throws SQLException;
}
