package impli;

import java.sql.SQLException;
import java.util.ArrayList;

import functions.Product;

public interface productim {
	//public Product getProduct(int pid)throws SQLException;
	
	public Product addproduct(Product d)throws SQLException ;
	
	public ArrayList<Product>getProducts()throws SQLException;
	
	public boolean updateproduct (Product d)throws SQLException;
	
	public boolean delete(int id) throws SQLException;

}
