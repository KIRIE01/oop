package impli;

import java.sql.SQLException;
import java.util.ArrayList;

import functions.User;

public interface userim {
	
	public User getUser(String name) throws SQLException;
	
	public Void addUser(User d) throws SQLException;
	
	public ArrayList<User>getUsers() throws SQLException;
	
	public boolean updateUser(User d)throws SQLException;
	
	public boolean delete (String name) throws SQLException;

	ArrayList<User> getUsers(String SELECT_ALL_User) throws SQLException;
	

}
